﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Test_SP.Startup))]
namespace Test_SP
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
